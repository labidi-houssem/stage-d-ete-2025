-- AlterTable
ALTER TABLE "Reservation" ADD COLUMN     "meetLink" TEXT;
