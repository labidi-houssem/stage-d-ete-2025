#!/bin/bash

echo "🚀 Creating users on the server..."

# Navigate to the app directory
cd /home/test/Documents/stage-d-ete-2025/my-app

# Run the user creation script
node create-users-script.js

echo "✅ User creation script completed!"

