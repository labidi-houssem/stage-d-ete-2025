import { NextResponse } from "next/server"

export const GET =()=>{
    return new NextResponse("THIS MY FIRST NEXT JS API");
};