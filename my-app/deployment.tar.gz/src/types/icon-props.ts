export interface IconProps {
  className?: string;
}